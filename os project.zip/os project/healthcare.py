import tkinter as tk
from tkinter import filedialog, messagebox
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes 
import os

class CryptoFilesystem:
    def __init__(self, password, salt=b'salt'):
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,salt=salt,iterations=100000, backend=default_backend() )
        key = kdf.derive(password.encode()) 
        self.key = key

    def encrypt(self, plaintext, filename):
        iv = os.urandom(16)
        cipher = Cipher(algorithms.AES(self.key), modes.CFB(iv), backend=default_backend()) 
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(plaintext.encode()) + encryptor.finalize()
        with open(filename, 'wb') as file: 
            file.write(iv + ciphertext)

    def decrypt(self, filename):
        with open(filename, 'rb') as file:
            data = file.read()
            iv = data[:16] 
            ciphertext = data[16:]
        cipher = Cipher(algorithms.AES(self.key), modes.CFB(iv), backend=default_backend()) 
        decryptor = cipher.decryptor()
        plaintext = decryptor.update(ciphertext) + decryptor.finalize() 
        return plaintext.decode()

class CryptoApp:
    def __init__(self, root):
        self.root = root 
        self.root.title("Crypto File System")
        self.crypto_filesystem = None 
        self.password_entry = tk.Entry(self.root, show="")
        self.create_widgets()
    
    def create_widgets(self):
        tk.Label(self.root, text="Enter Password:").pack()
        self.password_entry.pack()
        tk.Button(self.root, text="Submit Password", command=self.verify_password).pack()

    def verify_password(self):
        password = self.password_entry.get() 
        if not password:
            self.show_message("Password is required.") 
            return
        try:
            self.crypto_filesystem = CryptoFilesystem(password) 
            self.show_message("Password verified. You can now encrypt or decrypt files.") 
            self.create_file_buttons()
        except Exception as e:
            self.show_message(f"Error: {str(e)}")

    def create_file_buttons(self):
        tk.Button(self.root, text="Encrypt File", command=self.encrypt_file).pack() 
        tk.Button(self.root, text="Decrypt File", command=self.decrypt_file).pack()
    
    def encrypt_file(self):
        if not self.crypto_filesystem: 
            self.show_message("Please enter a password first.") 
            return
        file_path = filedialog.askopenfilename(title="Select a file to encrypt") 
        if not file_path:
            return
        with open(file_path, 'r') as file: 
            plaintext_data = file.read()
        encrypted_file_path = filedialog.asksaveasfilename(title="Save encrypted file as") 
        if encrypted_file_path:
            self.crypto_filesystem.encrypt(plaintext_data, encrypted_file_path) 
            self.show_message("File encrypted successfully.")
    
    def decrypt_file(self):
        if not self.crypto_filesystem:
            self.show_message("Please enter a password first.") 
            return
        file_path = filedialog.askopenfilename(title="Select a file to decrypt") 
        if not file_path:
            return
        decrypted_file_path = filedialog.asksaveasfilename(title="Save decrypted file as") 
        if decrypted_file_path:
            try:
                decrypted_data = self.crypto_filesystem.decrypt(file_path) 
                with open(decrypted_file_path, 'w') as file:
                    file.write(decrypted_data) 
                self.show_message("File decrypted successfully.")
            except Exception as e: 
                self.show_message(f"Error: {str(e)}")
    
    def show_message(self, message): 
        messagebox.showinfo("Info", message)

if __name__ == "__main__": root = tk.Tk()
app = CryptoApp(root) 
root.mainloop()
